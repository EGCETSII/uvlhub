console.log("Hi, I am a script loaded from team module");
