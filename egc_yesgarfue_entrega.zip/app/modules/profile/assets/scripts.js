console.log("Hi, I am a script loaded from profile module");
